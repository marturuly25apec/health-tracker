import streamlit as st
import json
import os

FILE_NAME = "health_data.json"

# -------------------- DATA --------------------

def load_data():
    if not os.path.exists(FILE_NAME):
        return {"water": [], "workouts": []}
    with open(FILE_NAME, "r") as f:
        return json.load(f)

def save_data(data):
    with open(FILE_NAME, "w") as f:
        json.dump(data, f)

# -------------------- FUNCTIONS --------------------

def add_water(amount):
    data = load_data()
    data["water"].append(amount)
    save_data(data)

def add_workout(name, duration):
    data = load_data()
    data["workouts"].append({
        "name": name,
        "duration": duration
    })
    save_data(data)

def get_total_water():
    data = load_data()
    return sum(data["water"])

def get_total_workout():
    data = load_data()
    return sum(w["duration"] for w in data["workouts"])

# -------------------- UI --------------------

st.title("🏃‍♂️ Трекер здоровья")

menu = st.sidebar.selectbox(
    "Меню",
    ["💧 Вода", "🏋️ Тренировки", "📊 Статистика", "📽 Презентация"]
)

# -------------------- WATER --------------------

if menu == "💧 Вода":
    st.header("💧 Трекер воды")

    water_amount = st.number_input("Сколько воды (мл)", min_value=0)

    if st.button("Добавить воду"):
        if water_amount == 0:
            st.warning("Введите значение")
        else:
            add_water(water_amount)
            st.success("Добавлено!")

    st.subheader("Всего воды")
    st.write(get_total_water(), "мл")

# -------------------- WORKOUTS --------------------

elif menu == "🏋️ Тренировки":
    st.header("🏋️ Тренировки")

    name = st.text_input("Название тренировки")
    duration = st.number_input("Длительность (мин)", min_value=0)

    if st.button("Добавить тренировку"):
        if name == "":
            st.warning("Введите название")
        else:
            add_workout(name, duration)
            st.success("Добавлено!")

    st.subheader("Список тренировок")

    data = load_data()

    if len(data["workouts"]) == 0:
        st.write("Нет тренировок")
    else:
        for w in data["workouts"]:
            st.write(f"{w['name']} — {w['duration']} мин")

# -------------------- STATS --------------------

elif menu == "📊 Статистика":
    st.header("📊 Статистика")

    st.write("💧 Всего воды:", get_total_water(), "мл")
    st.write("🏋️ Время тренировок:", get_total_workout(), "мин")

# -------------------- SLIDES --------------------

elif menu == "📽 Презентация":
    st.title("📽 Презентация проекта")

    slide = st.selectbox("Слайд", ["1", "2", "3"])

    if slide == "1":
        st.header("Проблема")
        st.write("Люди часто не следят за водой и физической активностью.")

    elif slide == "2":
        st.header("Решение")
        st.write("Приложение помогает отслеживать воду и тренировки.")

    elif slide == "3":
        st.header("Функции")
        st.write("""
        - Добавление воды  
        - Добавление тренировок  
        - Просмотр статистики  
        - Сохранение данных в JSON  
        """)