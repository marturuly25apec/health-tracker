import streamlit as st
import json
import os
from datetime import datetime

DATA_FILE = "data.json"

# -------------------- SETTINGS --------------------
st.set_page_config(
    page_title="Fitness Tracker",
    page_icon="🏋️‍♂️",
    layout="centered"
)

st.markdown("""
<style>
body {background-color: #0f172a;}
h1, h2, h3 {color: #38bdf8;}

.card {
    background-color: #1e293b;
    padding: 15px;
    border-radius: 12px;
    margin-bottom: 10px;
    color: white;
}

.stButton button {
    background-color: #38bdf8;
    color: black;
    border-radius: 10px;
    font-weight: bold;
}
</style>
""", unsafe_allow_html=True)

# -------------------- DATA --------------------
def load_data():
    if not os.path.exists(DATA_FILE):
        return []
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def save_data(data):
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

def add_record(t, v, c):
    data = load_data()
    data.append({
        "date": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "type": t,
        "value": v,
        "comment": c
    })
    save_data(data)

# -------------------- MENU --------------------
menu = st.sidebar.radio(
    "📌 Меню",
    ["🏠 Главная", "➕ Добавить", "🧠 План тренировок", "💧 Гид по здоровью"]
)

data = load_data()

# -------------------- HOME --------------------
if menu == "🏠 Главная":
    st.title("🏋️ Fitness Tracker")

    st.markdown("""
    <div class="card">
    💧 Вода — контроль гидратации<br>
    🏃‍♂️ Тренировки — фиксация активности<br>
    ⚖️ Вес — отслеживание прогресса<br><br>
    🧠 Умные советы и планы
    </div>
    """, unsafe_allow_html=True)

# -------------------- ADD --------------------
elif menu == "➕ Добавить":
    st.title("➕ Добавить запись")

    t = st.selectbox("Тип", ["Вода 💧", "Тренировка 🏃‍♂️", "Вес ⚖️"])
    v = st.number_input("Значение", min_value=0.0)
    c = st.text_input("Комментарий")

    if st.button("Сохранить"):
        if v <= 0:
            st.error("Введите корректное значение")
        else:
            add_record(t, v, c)
            st.success("Запись добавлена!")

# -------------------- TRAINING PLAN --------------------
elif menu == "🧠 План тренировок":
    st.title("🧠 План тренировок")

    goal = st.selectbox("Твоя цель", [
        "Похудение",
        "Набор массы",
        "Поддержание формы"
    ])

    if goal == "Похудение":
        st.markdown("""
        <div class="card">
        🏃‍♂️ Кардио 3–4 раза в неделю<br>
        💧 2–3 литра воды<br>
        🥗 Дефицит калорий<br>
        💤 7–8 часов сна
        </div>
        """, unsafe_allow_html=True)

    elif goal == "Набор массы":
        st.markdown("""
        <div class="card">
        🏋️‍♂️ Силовые 4–5 раз в неделю<br>
        🍗 Белок каждый день<br>
        💧 2–3 литра воды<br>
        💤 Восстановление обязательно
        </div>
        """, unsafe_allow_html=True)

    else:
        st.markdown("""
        <div class="card">
        ⚖️ 3 тренировки в неделю<br>
        🍎 Баланс питания<br>
        🚶‍♂️ Ежедневная активность<br>
        💧 Вода 2 литра+
        </div>
        """, unsafe_allow_html=True)

# -------------------- HEALTH GUIDE (NEW FEATURE) --------------------
elif menu == "💧 Гид по здоровью":
    st.title("💧 Умный гид по здоровью")

    water = st.number_input("Сколько воды ты выпил сегодня (мл)?", min_value=0)

    sleep = st.slider("Сколько часов ты спал?", 0, 12, 7)

    activity = st.selectbox("Уровень активности", [
        "Низкий 😴",
        "Средний 🚶‍♂️",
        "Высокий 🏃‍♂️"
    ])

    if st.button("Получить совет"):
        st.markdown("### 🧠 Рекомендация:")

        if water < 1500:
            st.warning("💧 Пей больше воды (минимум 2 литра в день)")

        if sleep < 7:
            st.warning("😴 Тебе нужно больше сна (7–8 часов)")

        if activity == "Низкий 😴":
            st.info("🏃‍♂️ Добавь хотя бы 20–30 минут активности")

        if water >= 2000 and sleep >= 7 and activity == "Высокий 🏃‍♂️":
            st.success("🔥 Отличный образ жизни! Продолжай в том же духе")